-- =====================================================================
--  JCash Banking App: SQLite schema (reference copy)
--  The app creates these automatically (see SqliteConnectionProvider.java).
--  Money is stored as TEXT because SQLite has no exact DECIMAL type.
-- =====================================================================
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    mobile_number TEXT    NOT NULL UNIQUE,
    pin           TEXT    NOT NULL,
    pin_salt      TEXT    NOT NULL,
    full_name     TEXT    NOT NULL,
    balance       TEXT    NOT NULL DEFAULT '0.00'
);

CREATE TABLE IF NOT EXISTS transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER NOT NULL REFERENCES users(id),
    type        TEXT    NOT NULL,
    amount      TEXT    NOT NULL,
    details     TEXT,
    created_at  TEXT    NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, created_at);

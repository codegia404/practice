-- =====================================================================
--  JCash Banking App: MySQL schema (reference copy)
--  The app creates these tables automatically on start-up
--  (see MySqlConnectionProvider.java). You only need this file if you
--  want to create the database by hand, e.g. in phpMyAdmin or MySQL Workbench.
-- =====================================================================
CREATE DATABASE IF NOT EXISTS jcash_db;
USE jcash_db;

CREATE TABLE IF NOT EXISTS users (
    id            BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
    mobile_number VARCHAR(11)   NOT NULL UNIQUE,
    pin           VARCHAR(64)   NOT NULL,      -- SHA-256 hash, never the raw PIN
    pin_salt      VARCHAR(32)   NOT NULL,
    full_name     VARCHAR(100)  NOT NULL,
    balance       DECIMAL(15,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
    id          BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id     BIGINT        NOT NULL,
    type        VARCHAR(20)   NOT NULL,        -- CASH_IN, TRANSFER_OUT, TRANSFER_IN
    amount      DECIMAL(15,2) NOT NULL,
    details     VARCHAR(255),
    created_at  DATETIME      NOT NULL,
    INDEX idx_transactions_user (user_id, created_at),
    CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id)
) ENGINE=InnoDB;

-- Useful queries while demonstrating:
-- SELECT id, mobile_number, full_name, balance FROM users;
-- SELECT * FROM transactions WHERE user_id = 1 ORDER BY created_at DESC;
-- EXPLAIN SELECT * FROM transactions WHERE user_id = 1;   -- shows the index is used

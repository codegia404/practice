package com.jcash.repository;

import com.jcash.model.Transaction;

import java.sql.SQLException;
import java.util.List;

/*
 * TransactionRepository: what we can do with transaction logs in storage.
 * Same idea as UserRepository: the service talks to this interface, and the
 * JDBC class behind it holds the SQL.
 */
public interface TransactionRepository {

    /** Inserts one log row and returns it with its generated id. */
    Transaction save(Transaction transaction) throws SQLException;

    /** All logs of one user, newest first. */
    List<Transaction> findByUserId(long userId) throws SQLException;
}

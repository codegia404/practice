package com.jcash.repository;

import com.jcash.model.User;
import com.jcash.util.DatabaseManager;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;

/*
 * ============================================================================
 *  JdbcUserRepository: the JDBC implementation of UserRepository
 * ============================================================================
 *  JDBC IN 4 STEPS (memorize this, it is asked in oral questioning!)
 *    1. Get a Connection        -> databaseManager.getConnection()
 *    2. Prepare a statement     -> connection.prepareStatement("... ? ...")
 *    3. Execute it              -> executeQuery() for SELECT,
 *                                  executeUpdate() for INSERT/UPDATE/DELETE
 *    4. Read the ResultSet      -> while (rs.next()) { rs.getString("col") }
 *    ...and close everything (try-with-resources does this for us).
 *
 *  WHY PreparedStatement AND NEVER STRING CONCATENATION?
 *    BAD:  "SELECT * FROM users WHERE mobile_number = '" + input + "'"
 *    If someone types   ' OR '1'='1   as their mobile number, the SQL becomes
 *    "... WHERE mobile_number = '' OR '1'='1'", which matches EVERY user.
 *    This attack is called SQL INJECTION. With "?" placeholders the driver
 *    sends the value SEPARATELY from the SQL, so it can never be treated
 *    as code. Bonus: the database can cache the compiled query (faster).
 *
 *  WHY LIST THE COLUMNS INSTEAD OF "SELECT *"?
 *    We only fetch what we need (less data to transfer = faster), and the
 *    code doesn't break if someone adds a column to the table later.
 *
 *  WORKS ON BOTH SQLITE AND MYSQL
 *    Every SQL statement here uses standard syntax that both databases
 *    understand. The dialect differences live only in the
 *    ConnectionProvider classes (the CREATE TABLE statements).
 * ============================================================================
 */
public class JdbcUserRepository implements UserRepository {

    // The column list is written once and reused (no copy-paste typos).
    private static final String COLUMNS = "id, mobile_number, pin, pin_salt, full_name, balance";

    private final DatabaseManager db;

    // DEPENDENCY INJECTION: we RECEIVE the DatabaseManager instead of creating one.
    public JdbcUserRepository(DatabaseManager db) {
        this.db = db;
    }

    @Override
    public Optional<User> findByMobileNumber(String mobileNumber) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM users WHERE mobile_number = ?";
        // try-with-resources: ps is closed automatically when the block ends.
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, mobileNumber);           // fills the 1st "?" (JDBC counts from 1!)
            try (ResultSet rs = ps.executeQuery()) {
                // rs.next() moves to the first row; it returns false if there is none.
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        }
    }

    @Override
    public Optional<User> findById(long id) throws SQLException {
        String sql = "SELECT " + COLUMNS + " FROM users WHERE id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setLong(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        }
    }

    @Override
    public User save(User user) throws SQLException {
        String sql = "INSERT INTO users (mobile_number, pin, pin_salt, full_name, balance) "
                   + "VALUES (?, ?, ?, ?, ?)";
        // RETURN_GENERATED_KEYS asks the driver to give back the new AUTO_INCREMENT id.
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, user.getMobileNumber());
            ps.setString(2, user.getPin());
            ps.setString(3, user.getPinSalt());
            ps.setString(4, user.getFullName());
            // toPlainString() gives "5000.00" (never "5E+3"). It works for
            // MySQL's DECIMAL column AND for our SQLite TEXT column.
            ps.setString(5, user.getBalance().toPlainString());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    user.setId(keys.getLong(1));
                }
            }
        }
        return user;
    }

    @Override
    public void updateBalance(long userId, BigDecimal newBalance) throws SQLException {
        String sql = "UPDATE users SET balance = ? WHERE id = ?";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setString(1, newBalance.toPlainString());
            ps.setLong(2, userId);
            int rows = ps.executeUpdate();   // how many rows were changed
            if (rows != 1) {
                // Never fail silently: if the row isn't there, the money update didn't happen.
                throw new SQLException("Balance update failed: user id " + userId + " not found");
            }
        }
    }

    @Override
    public long count() throws SQLException {
        try (PreparedStatement ps = db.getConnection().prepareStatement("SELECT COUNT(*) FROM users");
             ResultSet rs = ps.executeQuery()) {
            rs.next();
            return rs.getLong(1);
        }
    }

    /*
     * Converts ONE row of the ResultSet into ONE User object. This is called
     * "mapping" (object-relational mapping, the idea behind tools like
     * Hibernate). Reading the balance as a String and building a BigDecimal
     * works the same for SQLite (TEXT) and MySQL (DECIMAL).
     */
    private User mapRow(ResultSet rs) throws SQLException {
        return new User(
                rs.getLong("id"),
                rs.getString("mobile_number"),
                rs.getString("pin"),
                rs.getString("pin_salt"),
                rs.getString("full_name"),
                new BigDecimal(rs.getString("balance")));
    }
}

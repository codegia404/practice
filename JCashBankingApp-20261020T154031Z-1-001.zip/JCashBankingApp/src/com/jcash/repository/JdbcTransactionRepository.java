package com.jcash.repository;

import com.jcash.model.Transaction;
import com.jcash.model.TransactionType;
import com.jcash.util.DatabaseManager;

import java.math.BigDecimal;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/*
 * ============================================================================
 *  JdbcTransactionRepository: saves and reads the transaction logs
 * ============================================================================
 *  HOW WE STORE THE DATE SO IT WORKS ON BOTH DATABASES
 *    We write the date as text in the format "2026-10-20 14:30:05".
 *      - MySQL accepts that text for a DATETIME column.
 *      - SQLite has no date type at all, and stores it as TEXT.
 *    Because this format goes year -> month -> day -> time, sorting the
 *    text alphabetically also sorts it by time, so "ORDER BY created_at"
 *    works correctly on both.
 *
 *  HOW WE STORE THE TYPE
 *    We save the enum's NAME ("CASH_IN") and turn it back with
 *    TransactionType.valueOf("CASH_IN"). Names are stable and readable in
 *    the database, unlike ordinal numbers (0, 1, 2), which break if someone
 *    reorders the enum.
 * ============================================================================
 */
public class JdbcTransactionRepository implements TransactionRepository {

    private static final DateTimeFormatter DB_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private final DatabaseManager db;

    public JdbcTransactionRepository(DatabaseManager db) {
        this.db = db;
    }

    @Override
    public Transaction save(Transaction tx) throws SQLException {
        String sql = "INSERT INTO transactions (user_id, type, amount, details, created_at) "
                   + "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setLong(1, tx.getUserId());
            ps.setString(2, tx.getType().name());
            ps.setString(3, tx.getAmount().toPlainString());
            ps.setString(4, tx.getDetails());
            ps.setString(5, tx.getDateTime().format(DB_FORMAT));
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    tx.setId(keys.getLong(1));
                }
            }
        }
        return tx;
    }

    @Override
    public List<Transaction> findByUserId(long userId) throws SQLException {
        // "ORDER BY created_at DESC, id DESC" = newest first. The id is a
        // tie-breaker for two logs written in the same second (a transfer).
        // The index idx_transactions_user (user_id, created_at) makes this fast.
        String sql = "SELECT id, user_id, type, amount, details, created_at "
                   + "FROM transactions WHERE user_id = ? ORDER BY created_at DESC, id DESC";
        List<Transaction> result = new ArrayList<>();
        try (PreparedStatement ps = db.getConnection().prepareStatement(sql)) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {            // loop over EVERY row
                    result.add(mapRow(rs));
                }
            }
        }
        return result;
    }

    private Transaction mapRow(ResultSet rs) throws SQLException {
        // MySQL may return "2026-10-20 14:30:05.0"; we keep only the first 19 characters.
        String created = rs.getString("created_at");
        LocalDateTime dateTime = LocalDateTime.parse(created.substring(0, 19), DB_FORMAT);
        return new Transaction(
                rs.getLong("id"),
                rs.getLong("user_id"),
                TransactionType.valueOf(rs.getString("type")),
                new BigDecimal(rs.getString("amount")),
                rs.getString("details"),
                dateTime);
    }
}

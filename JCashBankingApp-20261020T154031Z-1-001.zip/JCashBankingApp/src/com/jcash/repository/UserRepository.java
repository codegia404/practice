package com.jcash.repository;

import com.jcash.model.User;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Optional;

/*
 * ============================================================================
 *  UserRepository: WHAT we can do with users in storage (an interface)
 * ============================================================================
 *  WHAT IS A "REPOSITORY"?
 *    A repository (also called a DAO, "Data Access Object") is the ONLY
 *    part of the app that writes SQL for one kind of object. The services
 *    call friendly methods like findByMobileNumber() and never see SQL.
 *
 *  WHY SEPARATE IT FROM THE SERVICE?
 *    - Services hold BUSINESS RULES ("you can't send more than your balance").
 *    - Repositories hold STORAGE DETAILS ("SELECT ... FROM users WHERE ...").
 *    Mixing both in one class gives a giant class that's hard to read and
 *    test. Splitting them gives a "layered architecture":
 *
 *       JCashApp (UI)  ->  service (rules)  ->  repository (SQL)  ->  database
 *
 *  WHY Optional<User>?
 *    A search can find nothing. Returning null is easy to forget to check,
 *    which leads to the famous NullPointerException. Optional FORCES the
 *    caller to think: "what if the user isn't there?"
 * ============================================================================
 */
public interface UserRepository {

    Optional<User> findByMobileNumber(String mobileNumber) throws SQLException;

    Optional<User> findById(long id) throws SQLException;

    /** Inserts a new user and returns it with its database-generated id filled in. */
    User save(User user) throws SQLException;

    /** Changes only the balance column of one user. */
    void updateBalance(long userId, BigDecimal newBalance) throws SQLException;

    long count() throws SQLException;
}

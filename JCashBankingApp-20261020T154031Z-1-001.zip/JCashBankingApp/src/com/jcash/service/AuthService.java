package com.jcash.service;

import com.jcash.model.User;
import com.jcash.repository.UserRepository;
import com.jcash.util.PinHasher;

import java.sql.SQLException;
import java.util.Optional;
import java.util.regex.Pattern;

/*
 * ============================================================================
 *  AuthService  (Step D: "Build the login feature")
 * ============================================================================
 *  RESPONSIBILITY: decide whether a mobile number + PIN pair is valid.
 *
 *  WHY DOESN'T THIS CLASS COUNT THE 3 ATTEMPTS ITSELF?
 *    Counting attempts means LOOPING and ASKING THE KEYBOARD again, and the
 *    keyboard belongs to the user interface (JCashApp). This class only
 *    answers ONE question per call: "is this one attempt valid?". The
 *    limit itself (MAX_LOGIN_ATTEMPTS) lives here because it's a business
 *    rule, and the UI reads it. Keeping keyboard code out of services
 *    means we could reuse this exact class in a web or mobile app.
 *
 *  WHY RETURN A "LoginResult" INSTEAD OF true/false?
 *    The checklist wants different messages for "mobile number does not
 *    exist" (D.2) and "PIN is incorrect" (D.3). A boolean can't say WHICH
 *    one failed, so we return a small object with a status code AND the
 *    user when the login worked.
 *
 *    Security side note (good for oral questions): many real banks
 *    deliberately show ONE vague message ("invalid mobile number or PIN")
 *    so attackers can't discover which numbers are registered. We show
 *    separate messages because the assessment asks us to verify each one.
 * ============================================================================
 */
public class AuthService {

    /** Spec D: "Allow up to 3 tries." A named constant instead of a magic number 3. */
    public static final int MAX_LOGIN_ATTEMPTS = 3;

    // Philippine mobile numbers: 11 digits starting with "09", e.g. 09171234567.
    // A compiled Pattern is created ONCE (static final). Compiling a regex is
    // costly, and String.matches() would re-compile it on every call.
    private static final Pattern MOBILE_PATTERN = Pattern.compile("^09\\d{9}$");
    private static final Pattern PIN_PATTERN = Pattern.compile("^\\d{4}$");

    /** The possible outcomes of one login attempt. */
    public enum Status { SUCCESS, INVALID_FORMAT, MOBILE_NOT_FOUND, WRONG_PIN }

    /*
     * A RECORD (Java 16+) is a short way to write an immutable data class.
     * This one line creates private final fields, a constructor, the getters
     * status() and user(), plus equals/hashCode/toString.
     */
    public record LoginResult(Status status, User user) {
        public boolean isSuccess() {
            return status == Status.SUCCESS;
        }
    }

    private final UserRepository userRepository;

    public AuthService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    /** Checks ONE login attempt. */
    public LoginResult login(String mobileNumber, String pin) throws SQLException {
        // 1) Cheap checks first: reject bad formats BEFORE touching the database.
        if (!isValidMobileNumber(mobileNumber) || !isValidPin(pin)) {
            return new LoginResult(Status.INVALID_FORMAT, null);
        }

        // 2) Checklist D.2: does the mobile number exist?
        Optional<User> found = userRepository.findByMobileNumber(mobileNumber);
        if (found.isEmpty()) {
            return new LoginResult(Status.MOBILE_NOT_FOUND, null);
        }

        // 3) Checklist D.3: is the PIN correct? We compare HASHES, never raw PINs.
        User user = found.get();
        if (!PinHasher.matches(pin, user.getPinSalt(), user.getPin())) {
            return new LoginResult(Status.WRONG_PIN, null);
        }
        return new LoginResult(Status.SUCCESS, user);
    }

    public static boolean isValidMobileNumber(String mobileNumber) {
        return mobileNumber != null && MOBILE_PATTERN.matcher(mobileNumber).matches();
    }

    public static boolean isValidPin(String pin) {
        return pin != null && PIN_PATTERN.matcher(pin).matches();
    }
}

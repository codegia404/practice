package com.jcash.service;

import com.jcash.exception.InsufficientBalanceException;
import com.jcash.exception.InvalidAmountException;
import com.jcash.exception.InvalidTransferException;
import com.jcash.exception.UserNotFoundException;
import com.jcash.model.Transaction;
import com.jcash.model.TransactionType;
import com.jcash.model.User;
import com.jcash.repository.TransactionRepository;
import com.jcash.repository.UserRepository;
import com.jcash.util.DatabaseManager;
import com.jcash.util.MoneyFormatter;

import java.math.BigDecimal;
import java.sql.SQLException;

/*
 * ============================================================================
 *  AccountService  (Steps E, F, G: balance, cash-in, transfer)
 * ============================================================================
 *  This is the HEART of the bank. Every rule about money lives here, and
 *  ONLY here. The UI asks; this class decides.
 *
 *  THE GOLDEN PATTERN FOR EVERY MONEY OPERATION
 *     1. VALIDATE the input    (amount > 0? receiver exists? enough balance?)
 *     2. BEGIN a transaction
 *     3. UPDATE balance(s)
 *     4. INSERT log row(s)
 *     5. COMMIT, or ROLLBACK if anything failed
 *     6. Only AFTER a successful commit, update the Java objects in memory
 *  Step 6 comes last on purpose: if the database rejected the change, the
 *  screen must not show a balance that was never saved.
 * ============================================================================
 */
public class AccountService {

    // Business limits as named constants. Real e-wallets have limits like
    // these, and the names explain the numbers better than raw values would.
    public static final BigDecimal MIN_AMOUNT = new BigDecimal("1.00");
    public static final BigDecimal MAX_AMOUNT_PER_TRANSACTION = new BigDecimal("50000.00");

    private final DatabaseManager db;
    private final UserRepository userRepository;
    private final TransactionRepository transactionRepository;

    public AccountService(DatabaseManager db, UserRepository userRepository,
                          TransactionRepository transactionRepository) {
        this.db = db;
        this.userRepository = userRepository;
        this.transactionRepository = transactionRepository;
    }

    // =========================================================================
    //  STEP E: BALANCE
    // =========================================================================
    /*
     * Checklist E.2: "The displayed balance matches the STORED user balance."
     * So we don't trust the copy in memory. We re-read the database (the
     * "single source of truth") and refresh the in-memory User too.
     */
    public BigDecimal getCurrentBalance(User user) throws SQLException, UserNotFoundException {
        User fresh = userRepository.findById(user.getId())
                .orElseThrow(() -> new UserNotFoundException("Account no longer exists."));
        user.setBalance(fresh.getBalance());
        return fresh.getBalance();
    }

    // =========================================================================
    //  STEP F: CASH-IN
    // =========================================================================
    public Transaction cashIn(User user, BigDecimal amount)
            throws InvalidAmountException, UserNotFoundException, SQLException {

        validateAmount(amount);                                   // 1. validate (F.2)

        db.beginTransaction();                                    // 2. begin
        try {
            // Re-read the balance INSIDE the transaction so we add to the real stored value.
            User fresh = userRepository.findById(user.getId())
                    .orElseThrow(() -> new UserNotFoundException("Account no longer exists."));
            BigDecimal newBalance = fresh.getBalance().add(amount);   // BigDecimal math: exact

            userRepository.updateBalance(user.getId(), newBalance);   // 3. update (F.3, F.4)
            Transaction tx = transactionRepository.save(              // 4. log (F.5)
                    new Transaction(user.getId(), TransactionType.CASH_IN, amount,
                            "Cash-in to own wallet"));

            db.commit();                                              // 5. commit

            user.setBalance(newBalance);                              // 6. update memory
            user.addTransaction(tx);
            return tx;
        } catch (Exception e) {
            // ANY error (SQL error, missing user, bug...) -> undo everything.
            db.rollbackQuietly();
            throw e;   // "precise rethrow": Java knows e can only be one of our declared types
        }
    }

    // =========================================================================
    //  STEP G: TRANSFER
    // =========================================================================
    /*
     * The spec says: "Validate receiver, amount, and sender balance."
     * We validate in order from CHEAPEST to MOST EXPENSIVE: plain Java checks
     * first, database lookups last. If the amount is wrong there's no reason
     * to query the database at all.
     */
    public Transaction transfer(User sender, String receiverMobile, BigDecimal amount)
            throws InvalidAmountException, InvalidTransferException,
                   UserNotFoundException, InsufficientBalanceException, SQLException {

        // ---- 1. VALIDATE (no database yet) ----
        validateAmount(amount);
        if (!AuthService.isValidMobileNumber(receiverMobile)) {
            throw new InvalidTransferException("Invalid mobile number format. Use 11 digits, e.g. 09171234567.");
        }
        if (receiverMobile.equals(sender.getMobileNumber())) {
            throw new InvalidTransferException("You cannot transfer money to your own account.");
        }

        db.beginTransaction();
        try {
            // ---- 1b. VALIDATE (needs the database) ----
            User receiver = userRepository.findByMobileNumber(receiverMobile)
                    .orElseThrow(() -> new UserNotFoundException(
                            "Receiver " + receiverMobile + " is not a registered JCash user."));
            User freshSender = userRepository.findById(sender.getId())
                    .orElseThrow(() -> new UserNotFoundException("Sender account no longer exists."));

            // compareTo() returns -1, 0, or 1. NEVER use "<" with BigDecimal,
            // and don't use equals() either: 5.0 and 5.00 are NOT equal().
            if (freshSender.getBalance().compareTo(amount) < 0) {
                throw new InsufficientBalanceException("Insufficient balance. Your balance is "
                        + MoneyFormatter.format(freshSender.getBalance()) + ".");
            }

            // ---- 3. UPDATE BOTH BALANCES ----
            BigDecimal newSenderBalance = freshSender.getBalance().subtract(amount);
            BigDecimal newReceiverBalance = receiver.getBalance().add(amount);
            userRepository.updateBalance(sender.getId(), newSenderBalance);
            userRepository.updateBalance(receiver.getId(), newReceiverBalance);

            // ---- 4. TWO LOGS: one for each side of the transfer ----
            Transaction senderLog = transactionRepository.save(new Transaction(
                    sender.getId(), TransactionType.TRANSFER_OUT, amount,
                    "Transfer to " + receiver.toDisplayString()));
            transactionRepository.save(new Transaction(
                    receiver.getId(), TransactionType.TRANSFER_IN, amount,
                    "Transfer from " + sender.toDisplayString()));

            // ---- 5. COMMIT: all 4 changes become permanent TOGETHER ----
            db.commit();

            // ---- 6. update memory only after success ----
            sender.setBalance(newSenderBalance);
            sender.addTransaction(senderLog);
            return senderLog;
        } catch (Exception e) {
            db.rollbackQuietly();   // receiver not found, low balance, SQL error -> nothing changes
            throw e;
        }
    }

    // =========================================================================
    //  SHARED VALIDATION: written ONCE, used by cash-in AND transfer (DRY)
    // =========================================================================
    private void validateAmount(BigDecimal amount) throws InvalidAmountException {
        if (amount == null) {
            throw new InvalidAmountException("Please enter a valid number, e.g. 500 or 250.75.");
        }
        if (amount.signum() <= 0) {
            throw new InvalidAmountException("Amount must be greater than zero.");
        }
        // scale() = number of decimal places. Pesos only have centavos (2 places).
        if (amount.stripTrailingZeros().scale() > 2) {
            throw new InvalidAmountException("Amount can only have up to 2 decimal places (centavos).");
        }
        if (amount.compareTo(MIN_AMOUNT) < 0) {
            throw new InvalidAmountException("Minimum amount is " + MoneyFormatter.format(MIN_AMOUNT) + ".");
        }
        if (amount.compareTo(MAX_AMOUNT_PER_TRANSACTION) > 0) {
            throw new InvalidAmountException("Maximum per transaction is "
                    + MoneyFormatter.format(MAX_AMOUNT_PER_TRANSACTION) + ".");
        }
    }
}

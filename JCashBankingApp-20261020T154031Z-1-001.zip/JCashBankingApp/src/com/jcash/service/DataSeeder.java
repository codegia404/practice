package com.jcash.service;

import com.jcash.model.Transaction;
import com.jcash.model.TransactionType;
import com.jcash.model.User;
import com.jcash.repository.TransactionRepository;
import com.jcash.repository.UserRepository;
import com.jcash.util.DatabaseManager;
import com.jcash.util.PinHasher;

import java.math.BigDecimal;
import java.sql.SQLException;

/*
 * ============================================================================
 *  DataSeeder: creates demo accounts the very first time the app runs
 * ============================================================================
 *  WHY?
 *    The spec has no "register" feature, but we need users to log in and
 *    receive transfers. "Seeding" means filling an empty database with
 *    starting data. It only runs when the users table is EMPTY, so it never
 *    duplicates accounts or overwrites real balances.
 *
 *  The opening balances are written as CASH_IN logs too, so every peso in
 *  the system can be traced to a transaction record (an "audit trail").
 * ============================================================================
 */
public class DataSeeder {

    private final DatabaseManager db;
    private final UserRepository userRepository;
    private final TransactionRepository transactionRepository;

    public DataSeeder(DatabaseManager db, UserRepository userRepository,
                      TransactionRepository transactionRepository) {
        this.db = db;
        this.userRepository = userRepository;
        this.transactionRepository = transactionRepository;
    }

    /** Returns true if demo users were created. */
    public boolean seedDemoUsersIfEmpty() throws SQLException {
        if (userRepository.count() > 0) {
            return false;
        }
        // One transaction for all inserts: faster (one commit/disk flush instead of six)
        // and all-or-nothing. That's "batching" at the data-access layer.
        db.beginTransaction();
        try {
            createUser("09171234567", "1234", "Juan Dela Cruz", "5000.00");
            createUser("09182345678", "5678", "Maria Santos", "3000.00");
            createUser("09193456789", "0000", "Pedro Reyes", "0.00");
            db.commit();
            return true;
        } catch (SQLException | RuntimeException e) {
            db.rollbackQuietly();
            throw e;
        }
    }

    private void createUser(String mobile, String pin, String name, String openingBalance) throws SQLException {
        String salt = PinHasher.generateSalt();
        BigDecimal balance = new BigDecimal(openingBalance);
        User user = userRepository.save(new User(mobile, PinHasher.hash(pin, salt), salt, name, balance));
        if (balance.signum() > 0) {
            transactionRepository.save(new Transaction(user.getId(), TransactionType.CASH_IN,
                    balance, "Opening balance"));
        }
    }
}

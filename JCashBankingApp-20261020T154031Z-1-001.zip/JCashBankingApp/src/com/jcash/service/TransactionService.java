package com.jcash.service;

import com.jcash.model.Transaction;
import com.jcash.model.User;
import com.jcash.repository.TransactionRepository;
import com.jcash.util.MoneyFormatter;

import java.sql.SQLException;
import java.util.List;

/*
 * ============================================================================
 *  TransactionService  (Step H: "Build the transaction logs feature")
 * ============================================================================
 *  "Show all cash-in and transfer records for the logged-in user."
 *
 *  LAZY LOADING (performance tuning, Step I)
 *    When a user logs in we do NOT load their whole history; we only need
 *    the balance. The list is loaded only when they open "Transaction Logs".
 *    A user with 10,000 old transactions logs in just as fast as a new user.
 * ============================================================================
 */
public class TransactionService {

    private final TransactionRepository transactionRepository;

    public TransactionService(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    /** Loads all logs from the database (newest first) and stores them in the User object. */
    public List<Transaction> getTransactionLogs(User user) throws SQLException {
        List<Transaction> logs = transactionRepository.findByUserId(user.getId());
        user.setTransactions(logs);   // keeps the model's "transaction list" (spec B) in sync
        return logs;
    }

    /*
     * Builds the whole table as ONE String using StringBuilder.
     * We pre-size it (about 120 characters per row) so the internal array
     * rarely has to grow and copy itself. Formatting is kept here, not in the
     * UI, so every screen that shows logs shows them the same way.
     */
    public String formatLogs(List<Transaction> logs) {
        if (logs.isEmpty()) {
            return "  No transactions yet.\n";
        }
        StringBuilder sb = new StringBuilder(200 + logs.size() * 120);
        String line = "-".repeat(104) + "\n";
        sb.append(line);
        // %-19s = left-aligned text, 19 characters wide. Makes neat columns.
        sb.append(String.format("%-4s %-19s %-18s %18s  %s%n", "#", "Date/Time", "Type", "Amount", "Details"));
        sb.append(line);
        int number = 1;
        for (Transaction tx : logs) {
            String sign = tx.getType().isCredit() ? "+" : "-";
            sb.append(String.format("%-4d %-19s %-18s %18s  %s%n",
                    number++,
                    tx.getDateTime().format(Transaction.DISPLAY_FORMAT),
                    tx.getType().getLabel(),
                    sign + " " + MoneyFormatter.format(tx.getAmount()),
                    tx.getDetails()));
        }
        sb.append(line);
        sb.append("  Total records: ").append(logs.size()).append('\n');
        return sb.toString();
    }
}

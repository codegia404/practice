package com.jcash.exception;

/**
 * Thrown when the sender tries to transfer more money than they have.
 * (Spec step G: "validate ... sender balance".)
 */
public class InsufficientBalanceException extends JCashException {

    public InsufficientBalanceException(String message) {
        super(message);
    }
}

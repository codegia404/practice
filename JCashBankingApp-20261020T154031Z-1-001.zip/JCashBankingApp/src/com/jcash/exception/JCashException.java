package com.jcash.exception;

/*
 * ============================================================================
 *  JCashException: the parent of all OUR business-rule errors
 * ============================================================================
 *  WHY CUSTOM EXCEPTIONS?
 *    When a transfer fails, the screen should say WHY: "receiver not found",
 *    "insufficient balance", or "invalid amount". With a custom exception
 *    class for each case, the code that catches the error can react
 *    differently to each one, and the class name documents the problem.
 *
 *  WHY A PARENT CLASS?
 *    Inheritance again! Code that doesn't care about the exact reason can
 *    write ONE catch block:   catch (JCashException e) { print(e.getMessage()); }
 *    and it will catch every child exception. That's polymorphism applied
 *    to errors.
 *
 *  WHY "extends Exception" (CHECKED) AND NOT RuntimeException?
 *    A CHECKED exception forces the caller to handle it (with try/catch or
 *    "throws"). A failed transfer is an EXPECTED situation that the UI
 *    MUST handle, so we want the compiler to remind us. RuntimeExceptions
 *    are for programmer bugs (like null pointers), not for business rules.
 * ============================================================================
 */
public class JCashException extends Exception {

    public JCashException(String message) {
        super(message);   // pass the message up to Exception, so getMessage() works
    }
}

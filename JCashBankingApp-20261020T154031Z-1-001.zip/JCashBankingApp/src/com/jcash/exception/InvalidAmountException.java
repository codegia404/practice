package com.jcash.exception;

/**
 * Thrown when an amount is zero, negative, has more than 2 decimal places,
 * or is above the per-transaction limit. (Checklist F.2: "accepts only valid
 * positive amounts", and G: "validate amount".)
 */
public class InvalidAmountException extends JCashException {

    public InvalidAmountException(String message) {
        super(message);
    }
}

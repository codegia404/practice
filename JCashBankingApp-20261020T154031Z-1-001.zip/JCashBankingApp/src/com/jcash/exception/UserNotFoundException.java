package com.jcash.exception;

/**
 * Thrown when no account matches a mobile number, for example a transfer
 * to a number that is not registered. (Spec step G: "validate receiver".)
 */
public class UserNotFoundException extends JCashException {

    public UserNotFoundException(String message) {
        super(message);
    }
}

package com.jcash.exception;

/**
 * Thrown when a transfer request is not allowed for a reason other than the
 * amount or balance. Examples: sending money to yourself, or typing a mobile
 * number in the wrong format.
 */
public class InvalidTransferException extends JCashException {

    public InvalidTransferException(String message) {
        super(message);
    }
}

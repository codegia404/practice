package com.jcash;

import com.jcash.exception.JCashException;
import com.jcash.model.Transaction;
import com.jcash.model.User;
import com.jcash.repository.JdbcTransactionRepository;
import com.jcash.repository.JdbcUserRepository;
import com.jcash.repository.TransactionRepository;
import com.jcash.repository.UserRepository;
import com.jcash.service.AccountService;
import com.jcash.service.AuthService;
import com.jcash.service.DataSeeder;
import com.jcash.service.TransactionService;
import com.jcash.util.DatabaseConfig;
import com.jcash.util.DatabaseManager;
import com.jcash.util.InputHelper;
import com.jcash.util.MoneyFormatter;
import com.jcash.util.PerformanceMonitor;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/*
 * ============================================================================
 *  JCashApp: the MAIN class (entry point + console user interface)
 * ============================================================================
 *  WHAT THIS CLASS DOES
 *    1. Wiring: creates every object and connects them together (main()).
 *    2. Menus: shows choices, reads the keyboard, prints results.
 *    It holds NO business rules. For example, it never checks "is the balance
 *    enough?"; it asks AccountService and prints the answer. If tomorrow we
 *    build a GUI or a web page, only this class gets replaced.
 *
 *  HOW THE OBJECTS ARE CONNECTED ("wiring" / dependency injection)
 *
 *    DatabaseConfig --creates--> ConnectionProvider (SQLite or MySQL)
 *                                       |
 *                                 DatabaseManager (1 connection)
 *                                 /                \
 *                 JdbcUserRepository      JdbcTransactionRepository
 *                        |      \               /         |
 *                  AuthService   AccountService     TransactionService
 *                         \            |               /
 *                                  JCashApp (menus)
 *
 *    Everything is created in ONE place (main) and handed down through
 *    constructors. No class secretly creates its own dependencies, so the
 *    whole structure is visible right here.
 * ============================================================================
 */
public class JCashApp {

    private final InputHelper input;
    private final AuthService authService;
    private final AccountService accountService;
    private final TransactionService transactionService;
    private final String databaseName;

    public JCashApp(InputHelper input, AuthService authService, AccountService accountService,
                    TransactionService transactionService, String databaseName) {
        this.input = input;
        this.authService = authService;
        this.accountService = accountService;
        this.transactionService = transactionService;
        this.databaseName = databaseName;
    }

    // =========================================================================
    //  main(): the program starts here
    // =========================================================================
    public static void main(String[] args) {
        String configPath = System.getProperty("jcash.config", DatabaseConfig.DEFAULT_CONFIG_PATH);

        DatabaseManager db;
        try {
            DatabaseConfig config = new DatabaseConfig(configPath);
            db = new DatabaseManager(config.createProvider());   // polymorphism picks SQLite or MySQL
        } catch (Exception e) {
            System.err.println("Configuration error: " + e.getMessage());
            System.exit(1);
            return;   // never reached; it just tells the compiler "db" is always assigned below
        }

        // try-with-resources on DatabaseManager AND Scanner: both are closed
        // automatically when the program leaves this block, even after an error.
        try (db; Scanner scanner = new Scanner(System.in)) {
            db.initializeSchema();

            UserRepository userRepo = new JdbcUserRepository(db);
            TransactionRepository txRepo = new JdbcTransactionRepository(db);

            if (new DataSeeder(db, userRepo, txRepo).seedDemoUsersIfEmpty()) {
                System.out.println("[setup] Demo accounts created (see README / guide).");
            }

            JCashApp app = new JCashApp(
                    new InputHelper(scanner),
                    new AuthService(userRepo),
                    new AccountService(db, userRepo, txRepo),
                    new TransactionService(txRepo),
                    db.getDatabaseName());
            app.run();
        } catch (SQLException e) {
            System.err.println("\nDatabase error: " + e.getMessage());
            System.err.println("Tip: if you use MySQL, make sure the server is running (scripts/start-mysql.sh)"
                    + " and that config/db.properties has the correct user/password.");
            System.exit(2);
        } catch (InputHelper.InputClosedException e) {
            System.out.println("\nInput ended. Goodbye!");
        }
    }

    // =========================================================================
    //  MAIN MENU (before login)
    // =========================================================================
    public void run() throws SQLException {
        printBanner();
        boolean running = true;
        while (running) {
            System.out.println("\n=========== JCASH MAIN MENU ===========");
            System.out.println("[1] Login");
            System.out.println("[2] System Performance Monitor");
            System.out.println("[0] Exit");
            int choice = input.readMenuChoice("Choose an option: ", 0, 2);

            // "switch" with arrows: no "break" needed and no accidental fall-through.
            switch (choice) {
                case 1 -> {
                    User user = loginWithAttempts();
                    if (user != null) {
                        userMenu(user);
                    } else {
                        // Checklist D.4: 3 attempts ONLY. After the third failure we
                        // close the app instead of going back to the menu, otherwise
                        // the user could just pick "Login" again for 3 more tries.
                        // We leave the loop (not System.exit) so main() can still
                        // close the database connection properly.
                        running = false;
                    }
                }
                case 2 -> showPerformanceMenu();
                case 0 -> running = false;
                default -> { /* can't happen: readMenuChoice only allows 0..2 */ }
            }
        }
        System.out.println("\nThank you for using JCash Bank of the Philippines. Goodbye!");
    }

    // =========================================================================
    //  STEP D: LOGIN WITH UP TO 3 ATTEMPTS
    // =========================================================================
    /*
     * A classic "for" loop is the natural choice: we know the MAXIMUM number
     * of repetitions (3). We "return" early as soon as one attempt succeeds.
     */
    private User loginWithAttempts() throws SQLException {
        System.out.println("\n---------------- LOGIN ----------------");
        for (int attempt = 1; attempt <= AuthService.MAX_LOGIN_ATTEMPTS; attempt++) {
            System.out.println("Attempt " + attempt + " of " + AuthService.MAX_LOGIN_ATTEMPTS);
            String mobile = input.readLine("Mobile number (e.g. 09171234567): ");
            String pin = input.readLine("4-digit PIN: ");

            AuthService.LoginResult result = authService.login(mobile, pin);
            if (result.isSuccess()) {
                User user = result.user();
                System.out.println("\nLogin successful! Welcome, " + user.getFullName() + ".");
                // Checklist E.1: show the current balance right after a successful login.
                showBalance(user);
                return user;
            }

            // Checklist D.5: an appropriate message for each kind of failure.
            String reason = switch (result.status()) {
                case INVALID_FORMAT -> "Invalid format. Mobile must be 11 digits starting with 09; PIN must be 4 digits.";
                case MOBILE_NOT_FOUND -> "Mobile number is not registered.";
                case WRONG_PIN -> "Incorrect PIN.";
                case SUCCESS -> "";   // handled above; listed so the switch covers every enum value
            };
            int remaining = AuthService.MAX_LOGIN_ATTEMPTS - attempt;
            System.out.println("  Login failed: " + reason
                    + (remaining > 0 ? " You have " + remaining + " attempt(s) left.\n" : ""));
        }
        System.out.println("  Too many failed attempts. Access denied.");
        System.out.println("  For your security, the application will now close.");
        return null;
    }

    // =========================================================================
    //  USER MENU (after login)
    // =========================================================================
    private void userMenu(User user) throws SQLException {
        boolean loggedIn = true;
        while (loggedIn) {
            System.out.println("\n============ JCASH ACCOUNT ============");
            System.out.println("Logged in as: " + user.toDisplayString());
            System.out.println("[1] Check Balance");
            System.out.println("[2] Cash-In");
            System.out.println("[3] Transfer Money");
            System.out.println("[4] Transaction Logs");
            System.out.println("[5] System Performance Monitor");
            System.out.println("[0] Logout");
            int choice = input.readMenuChoice("Choose an option: ", 0, 5);
            switch (choice) {
                case 1 -> showBalance(user);
                case 2 -> cashIn(user);
                case 3 -> transfer(user);
                case 4 -> showLogs(user);
                case 5 -> showPerformanceMenu();
                case 0 -> {
                    loggedIn = false;
                    System.out.println("You have been logged out.");
                }
                default -> { }
            }
        }
    }

    // ---- STEP E: Balance ---------------------------------------------------------
    private void showBalance(User user) throws SQLException {
        try {
            BigDecimal balance = accountService.getCurrentBalance(user);
            System.out.println("  Current balance: " + MoneyFormatter.format(balance));
        } catch (JCashException e) {
            System.out.println("  " + e.getMessage());
        }
    }

    // ---- STEP F: Cash-In ----------------------------------------------------------
    private void cashIn(User user) throws SQLException {
        System.out.println("\n--------------- CASH-IN ---------------");
        BigDecimal amount = MoneyFormatter.parse(input.readLine("Enter amount to cash in: "));
        try {
            Transaction tx = accountService.cashIn(user, amount);
            System.out.println("  Cash-in successful! " + MoneyFormatter.format(tx.getAmount()) + " added.");
            System.out.println("  New balance: " + MoneyFormatter.format(user.getBalance()));
        } catch (JCashException e) {
            // ONE catch for every business error, thanks to the JCashException parent class.
            System.out.println("  Cash-in failed: " + e.getMessage());
        }
    }

    // ---- STEP G: Transfer ---------------------------------------------------------
    private void transfer(User user) throws SQLException {
        System.out.println("\n--------------- TRANSFER --------------");
        String receiver = input.readLine("Receiver mobile number: ");
        BigDecimal amount = MoneyFormatter.parse(input.readLine("Amount to send: "));

        // Ask for confirmation before moving money, like every real e-wallet does.
        String amountText = amount == null ? "?" : MoneyFormatter.format(amount);
        String confirm = input.readLine("Send " + amountText + " to " + receiver + "? (Y/N): ");
        if (!confirm.equalsIgnoreCase("Y")) {
            System.out.println("  Transfer cancelled.");
            return;
        }
        try {
            Transaction tx = accountService.transfer(user, receiver, amount);
            System.out.println("  Transfer successful! " + tx.getDetails());
            System.out.println("  New balance: " + MoneyFormatter.format(user.getBalance()));
        } catch (JCashException e) {
            System.out.println("  Transfer failed: " + e.getMessage());
        }
    }

    // ---- STEP H: Transaction logs --------------------------------------------------
    private void showLogs(User user) throws SQLException {
        System.out.println("\n----------- TRANSACTION LOGS ----------");
        List<Transaction> logs = transactionService.getTransactionLogs(user);
        System.out.print(transactionService.formatLogs(logs));
    }

    // ---- STEP I: Performance ------------------------------------------------------
    private void showPerformanceMenu() {
        System.out.println("\n[1] Show JVM / OS performance report");
        System.out.println("[2] Run language-level performance demo");
        System.out.println("[0] Back");
        int choice = input.readMenuChoice("Choose an option: ", 0, 2);
        if (choice == 1) {
            System.out.print(PerformanceMonitor.buildReport());
        } else if (choice == 2) {
            System.out.print(PerformanceMonitor.runLanguageLevelBenchmarks());
        }
    }

    private void printBanner() {
        System.out.println("""

                 =============================================
                  JCASH BANK OF THE PHILIPPINES
                  JCash Banking App  |  Database: %s
                 =============================================""".formatted(databaseName));
    }
}

package com.jcash.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/*
 * ============================================================================
 *  User  (Step B of the assessment: "Create the User model")
 * ============================================================================
 *  WHAT IS A "MODEL"?
 *    A model class is a plain object that HOLDS DATA. It does not talk to
 *    the database and it does not print menus. Keeping it "dumb" means it
 *    can be reused anywhere (console app, web app, unit tests...).
 *
 *  HOW WE CAME UP WITH THESE FIELDS
 *    The spec literally lists them: "Store mobile number, PIN, full name,
 *    balance, and transaction list." The checklist adds "user ID as long".
 *    A simple trick when reading any spec:
 *        NOUNS  -> become classes or fields   (user, PIN, balance...)
 *        VERBS  -> become methods             (log in, cash in, transfer...)
 *
 *  SECURITY DECISION: WE DO NOT STORE THE RAW PIN
 *    If someone steals the database, plain PINs would let them log in as
 *    anyone. So we store a HASH of the PIN (a one-way scrambled version)
 *    plus a random SALT. When a user logs in, we hash what they typed and
 *    compare hashes. See util/PinHasher.java for the full explanation.
 *    The "pin" field holds that hash, so the PIN is still a user attribute.
 *
 *  WHY BigDecimal FOR MONEY, NOT double?
 *    double is a BINARY floating-point number and can't represent 0.10
 *    exactly.  Try it:  System.out.println(0.1 + 0.2);  // 0.30000000000000004
 *    In a bank those tiny errors pile up. BigDecimal stores exact decimal
 *    digits, so 0.10 + 0.20 is exactly 0.30. ALWAYS use BigDecimal for money.
 * ============================================================================
 */
public class User extends BaseEntity {   // "extends" = User inherits id/getId/setId

    // ---- Encapsulated fields: all private (checklist B.4) -----------------
    private String mobileNumber;          // e.g. "09171234567", used to log in and to receive transfers
    private String pin;                   // the 4-digit PIN, stored as a salted SHA-256 hash (never the raw digits)
    private String pinSalt;               // random value mixed into the hash (see PinHasher)
    private String fullName;
    private BigDecimal balance;
    private List<Transaction> transactions;   // the user's transaction list (spec B)

    // ---- Constructors (checklist B.5) ----------------------------------------

    /*
     * No-argument constructor. Useful when we want to create an empty object
     * and fill it with setters (for example, when reading a row from the DB).
     * We still set safe defaults so nothing is ever null by accident.
     */
    public User() {
        super();                                  // call BaseEntity() first
        this.balance = BigDecimal.ZERO.setScale(2);
        this.transactions = new ArrayList<>();
    }

    /*
     * Constructor for a NEW user (not saved yet, so no id).
     * "this(...)" calls the no-arg constructor above first to reuse its defaults.
     */
    public User(String mobileNumber, String pin, String pinSalt,
                String fullName, BigDecimal balance) {
        this();
        this.mobileNumber = mobileNumber;
        this.pin = pin;
        this.pinSalt = pinSalt;
        this.fullName = fullName;
        setBalance(balance);                      // reuse the setter's rounding rule
    }

    /* Full constructor: used by the repository when loading an existing row. */
    public User(long id, String mobileNumber, String pin, String pinSalt,
                String fullName, BigDecimal balance) {
        this(mobileNumber, pin, pinSalt, fullName, balance);
        setId(id);
    }

    // ---- Getters and setters (checklist B.5) ----------------------------------
    // Why getters/setters instead of public fields? Because the class keeps
    // CONTROL. Look at setBalance(): it can refuse null and fix the decimal
    // places. A public field could never do that.

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    public String getPin() {
        return pin;
    }

    public void setPin(String pin) {
        this.pin = pin;
    }

    public String getPinSalt() {
        return pinSalt;
    }

    public void setPinSalt(String pinSalt) {
        this.pinSalt = pinSalt;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public BigDecimal getBalance() {
        return balance;
    }

    /*
     * The setter protects the object: money always has exactly 2 decimal
     * places (centavos) and can never be null or negative.
     */
    public void setBalance(BigDecimal balance) {
        if (balance == null) {
            throw new IllegalArgumentException("Balance cannot be null");
        }
        if (balance.signum() < 0) {
            throw new IllegalArgumentException("Balance cannot be negative");
        }
        this.balance = balance.setScale(2, RoundingMode.HALF_UP);
    }

    /*
     * We return an UNMODIFIABLE view of the list. Why? If we returned the
     * real list, any outside code could call getTransactions().clear() and
     * erase the history behind our back. That is called "leaking" internal
     * state, and it breaks encapsulation. Outside code may READ the list;
     * to change it, they must use setTransactions() or addTransaction().
     */
    public List<Transaction> getTransactions() {
        return Collections.unmodifiableList(transactions);
    }

    public void setTransactions(List<Transaction> transactions) {
        // Defensive copy: we copy the incoming list so later changes made
        // by the caller to THEIR list don't affect OUR list.
        this.transactions = (transactions == null) ? new ArrayList<>() : new ArrayList<>(transactions);
    }

    public void addTransaction(Transaction transaction) {
        this.transactions.add(transaction);
    }

    // ---- Polymorphism: our own version of the parent's abstract method -------
    @Override   // @Override asks the compiler to check that we really override a parent method
    public String toDisplayString() {
        return fullName + " (" + maskMobile(mobileNumber) + ")";
    }

    /*
     * Shows only the last 4 digits of the mobile number, e.g. "*******4567".
     * We use this when showing OTHER people's numbers on screen, a common
     * privacy practice in real e-wallets.
     */
    public static String maskMobile(String mobile) {
        if (mobile == null || mobile.length() < 4) {
            return "****";
        }
        return "*".repeat(mobile.length() - 4) + mobile.substring(mobile.length() - 4);
    }

    /*
     * toString() is used when debugging/printing an object. NOTICE: we
     * deliberately DON'T print pin or pinSalt. Secrets should never end
     * up in logs or on screen.
     */
    @Override
    public String toString() {
        return "User{id=" + getId() + ", mobileNumber='" + mobileNumber
                + "', fullName='" + fullName + "', balance=" + balance + "}";
    }
}

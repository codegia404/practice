package com.jcash.model;

/*
 * ============================================================================
 *  TransactionType  (an "enum")
 * ============================================================================
 *  WHAT IS AN ENUM?
 *    An enum is a fixed list of named constants. Our app only has three
 *    kinds of transactions, so we list them here and nowhere else.
 *
 *  WHY NOT JUST USE A String LIKE "cash in"?
 *    With Strings, a typo like "cashin" or "Cash-in" would compile fine but
 *    silently break our logs. With an enum, the COMPILER checks the spelling
 *    for us: TransactionType.CASH_IN either exists or the code won't build.
 *    Rule of thumb: when a value can only be one of a few known options,
 *    use an enum.
 *
 *  WHY ARE THERE TWO TRANSFER TYPES?
 *    A transfer touches TWO users. The sender's log should say "Transfer
 *    Sent" (money went out) and the receiver's log should say "Transfer
 *    Received" (money came in). Storing them separately makes each user's
 *    transaction history easy to read and easy to query.
 * ============================================================================
 */
public enum TransactionType {

    CASH_IN("Cash-In", true),
    TRANSFER_OUT("Transfer Sent", false),
    TRANSFER_IN("Transfer Received", true);

    // Enums can have fields and constructors, just like classes.
    private final String label;      // human-friendly text for the screen
    private final boolean credit;    // true = money comes IN, false = money goes OUT

    // An enum constructor is always private; Java creates the 3 objects above.
    TransactionType(String label, boolean credit) {
        this.label = label;
        this.credit = credit;
    }

    public String getLabel() {
        return label;
    }

    /** true if this type ADDS money to the balance (shown as "+" in logs). */
    public boolean isCredit() {
        return credit;
    }
}

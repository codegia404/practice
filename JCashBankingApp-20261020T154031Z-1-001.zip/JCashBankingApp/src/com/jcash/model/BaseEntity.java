package com.jcash.model;

/*
 * ============================================================================
 *  BaseEntity  (package: com.jcash.model)
 * ============================================================================
 *  WHAT IS THIS?
 *    The PARENT class of every object we save in the database (User and
 *    Transaction). It holds the one thing that ALL saved objects have in
 *    common: a numeric ID that acts as the primary key.
 *
 *  WHY DID WE CREATE IT? (How we "came up with" it)
 *    While designing, we listed the fields of User and Transaction and saw
 *    that both needed an "id" field, plus getId() and setId(). Copy-pasting
 *    the same code into two classes breaks the DRY rule ("Don't Repeat
 *    Yourself"). So we moved the shared part UP into a parent class. This is
 *    INHERITANCE, one of the four pillars of OOP:
 *
 *        BaseEntity            <- parent (superclass)
 *          ├── User            <- child (subclass)  "User IS-A BaseEntity"
 *          └── Transaction     <- child (subclass)
 *
 *  WHY "abstract"?
 *    "abstract" means you can NOT write "new BaseEntity()". That makes sense:
 *    a "base entity" by itself is not a real thing in our bank. Only a User
 *    or a Transaction is real. abstract classes exist only to be extended.
 *
 *  WHY "long" FOR THE ID?
 *    The assessment checklist (B.2) says the ID must be a long. A long can
 *    hold numbers up to about 9 quintillion, so we will never run out of IDs,
 *    and it maps directly to the BIGINT column type in the database.
 * ============================================================================
 */
public abstract class BaseEntity {

    // "private" = only code INSIDE this class can touch the field directly.
    // Everyone else must go through getId()/setId(). This is ENCAPSULATION.
    private long id;

    // "protected" constructor: only subclasses (User, Transaction) may call it.
    // A brand-new object that is not yet saved has id = 0; the database gives
    // it a real ID when we INSERT it.
    protected BaseEntity() {
        this.id = 0L;
    }

    protected BaseEntity(long id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    /**
     * Returns true when this object has not been saved to the database yet.
     * (We treat an ID of 0 as "no ID yet", because databases start at 1.)
     */
    public boolean isNew() {
        return id == 0L;
    }

    /*
     * ABSTRACT METHOD = a method with NO body. Every subclass is FORCED to
     * write its own version. This is the setup for POLYMORPHISM:
     *
     *     BaseEntity e = someUserOrTransaction;
     *     System.out.println(e.toDisplayString());
     *
     * Java decides at RUN TIME which version to call (User's or
     * Transaction's), depending on the real object. Same method call,
     * different behavior = "poly" (many) + "morph" (forms).
     */
    public abstract String toDisplayString();
}

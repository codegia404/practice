package com.jcash.model;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/*
 * ============================================================================
 *  Transaction  (Step C of the assessment: "Create the Transaction model")
 * ============================================================================
 *  The spec says: "Store transaction type, amount, details, and date/time."
 *  We add two more fields that the DATABASE needs:
 *     - id       (inherited from BaseEntity) -> the primary key
 *     - userId   -> WHICH user this log belongs to (the foreign key)
 *
 *  WHY LocalDateTime?
 *    It is Java's modern date/time class (since Java 8). The old
 *    java.util.Date is mutable and confusing. LocalDateTime is immutable
 *    (it can't be changed after it is created), which makes it safe to share.
 *
 *  WHY IS THE FORMATTER "static final"?
 *    A DateTimeFormatter is thread-safe and never changes, so we create
 *    it ONCE for the whole program instead of every time we print a date.
 *    Creating objects again and again for no reason wastes memory and CPU.
 *    This is a small LANGUAGE-LEVEL PERFORMANCE TUNING habit (Step I).
 * ============================================================================
 */
public class Transaction extends BaseEntity {

    public static final DateTimeFormatter DISPLAY_FORMAT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd hh:mm a");

    // ---- Encapsulated fields (checklist C.2 and C.3) --------------------------
    private long userId;
    private TransactionType type;
    private BigDecimal amount;
    private String details;            // e.g. "Transfer to Maria Santos (*******4567)"
    private LocalDateTime dateTime;

    // ---- Constructors (checklist C.4) -----------------------------------------

    public Transaction() {
        super();
        this.amount = BigDecimal.ZERO.setScale(2);
        this.dateTime = LocalDateTime.now();
    }

    /* Constructor for a NEW transaction that is about to be saved. */
    public Transaction(long userId, TransactionType type, BigDecimal amount, String details) {
        this();
        this.userId = userId;
        this.type = type;
        setAmount(amount);
        this.details = details;
        // Seconds are enough for a bank log. Dropping the nanoseconds also
        // makes the value identical in SQLite and MySQL.
        this.dateTime = LocalDateTime.now().withNano(0);
    }

    /* Full constructor used by the repository when reading an existing row. */
    public Transaction(long id, long userId, TransactionType type, BigDecimal amount,
                       String details, LocalDateTime dateTime) {
        this(userId, type, amount, details);
        setId(id);
        this.dateTime = dateTime;
    }

    // ---- Getters and setters ----------------------------------------------------

    public long getUserId() {
        return userId;
    }

    public void setUserId(long userId) {
        this.userId = userId;
    }

    public TransactionType getType() {
        return type;
    }

    public void setType(TransactionType type) {
        this.type = type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        if (amount == null || amount.signum() <= 0) {
            throw new IllegalArgumentException("Transaction amount must be greater than zero");
        }
        this.amount = amount.setScale(2, RoundingMode.HALF_UP);
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    // ---- Polymorphism: Transaction's own version of toDisplayString() ---------
    @Override
    public String toDisplayString() {
        String sign = type.isCredit() ? "+" : "-";
        return dateTime.format(DISPLAY_FORMAT) + " | " + type.getLabel() + " | "
                + sign + amount.toPlainString() + " | " + details;
    }

    @Override
    public String toString() {
        return "Transaction{id=" + getId() + ", userId=" + userId + ", type=" + type
                + ", amount=" + amount + ", details='" + details + "', dateTime=" + dateTime + "}";
    }
}

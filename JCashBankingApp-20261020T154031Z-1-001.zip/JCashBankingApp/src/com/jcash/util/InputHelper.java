package com.jcash.util;

import java.util.Scanner;

/*
 * ============================================================================
 *  InputHelper: safe keyboard input
 * ============================================================================
 *  THE CLASSIC BEGINNER BUG THIS AVOIDS
 *    Mixing scanner.nextInt() and scanner.nextLine() causes "skipped"
 *    input: nextInt() reads the number but leaves the Enter key ("\n") in
 *    the buffer, so the next nextLine() immediately returns an empty line.
 *    FIX: always read a WHOLE line with nextLine(), then convert it
 *    ourselves. That's what every method here does.
 *
 *  ALSO: nextInt() CRASHES (InputMismatchException) when the user types
 *  "abc". Reading text and converting it ourselves lets us show a friendly
 *  message and ask again instead of crashing.
 *
 *  WHY ONE SHARED Scanner?
 *    Creating several Scanners on System.in and closing one of them closes
 *    System.in for the whole program. One Scanner for the whole app avoids that.
 * ============================================================================
 */
public class InputHelper {

    private final Scanner scanner;

    public InputHelper(Scanner scanner) {
        this.scanner = scanner;
    }

    /*
     * Prints a prompt and returns the trimmed line the user typed.
     * If input has ended (Ctrl+D, or the end of a piped test file) we throw
     * a special exception so the app can shut down cleanly instead of looping.
     */
    public String readLine(String prompt) {
        System.out.print(prompt);
        if (!scanner.hasNextLine()) {
            throw new InputClosedException();
        }
        return scanner.nextLine().trim();
    }

    /* Keeps asking until the user types a whole number between min and max. */
    public int readMenuChoice(String prompt, int min, int max) {
        while (true) {
            String text = readLine(prompt);
            try {
                int value = Integer.parseInt(text);
                if (value >= min && value <= max) {
                    return value;
                }
            } catch (NumberFormatException ignored) {
                // fall through to the error message below
            }
            System.out.println("  Please enter a number from " + min + " to " + max + ".");
        }
    }

    /** Signals that there is no more input (end of file). */
    public static class InputClosedException extends RuntimeException {
        public InputClosedException() {
            super("Input stream closed");
        }
    }
}

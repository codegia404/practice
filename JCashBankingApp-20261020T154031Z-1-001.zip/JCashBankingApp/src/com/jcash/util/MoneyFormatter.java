package com.jcash.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;

/*
 * ============================================================================
 *  MoneyFormatter: one place that decides how money looks and is parsed
 * ============================================================================
 *  WHY A SEPARATE CLASS?
 *    Money is shown on many screens (balance, cash-in, transfer, logs). If
 *    each screen formatted it its own way, they would soon look different.
 *    One shared formatter = one rule = consistent output. This is the
 *    "Single Responsibility Principle" (the "S" in SOLID).
 *
 *  WHY "PHP" INSTEAD OF THE PESO SIGN?
 *    Some terminals (especially older Windows consoles) print "?" instead
 *    of the peso sign because of character encoding. "PHP" is the official
 *    ISO currency code and displays correctly everywhere.
 * ============================================================================
 */
public final class MoneyFormatter {

    private MoneyFormatter() {
    }

    /*
     * Formats 5000 as "PHP 5,000.00".
     * DecimalFormat is NOT thread-safe, which is why we don't keep a shared
     * static instance. Our app is single-threaded, but this is the safe habit.
     */
    public static String format(BigDecimal amount) {
        DecimalFormat df = new DecimalFormat("#,##0.00");
        return "PHP " + df.format(amount.setScale(2, RoundingMode.HALF_UP));
    }

    /*
     * Turns user text like "1,500.50" into a BigDecimal.
     * Returns null when the text is not a number, so the caller can show an error.
     * NOTE: we build the BigDecimal from the STRING, never from a double:
     *    new BigDecimal("0.1") -> exactly 0.1
     *    new BigDecimal(0.1)   -> 0.1000000000000000055511151231257827...
     */
    public static BigDecimal parse(String text) {
        if (text == null) {
            return null;
        }
        String cleaned = text.trim().replace(",", "");
        if (cleaned.isEmpty()) {
            return null;
        }
        try {
            return new BigDecimal(cleaned);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}

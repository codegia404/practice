package com.jcash.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

/*
 * ============================================================================
 *  MySqlConnectionProvider: the MySQL implementation of ConnectionProvider
 * ============================================================================
 *  WHAT IS DIFFERENT FROM SQLITE?
 *    - MySQL is a SERVER. It must be running before the app starts (see
 *      scripts/start-mysql.sh, which runs MySQL inside Docker).
 *    - It needs a username and password.
 *    - It has a REAL exact DECIMAL(15,2) type, so money is stored as a number.
 *    - Auto-increment is spelled AUTO_INCREMENT and the ID type is BIGINT
 *      (BIGINT in SQL = long in Java).
 *
 *  PERFORMANCE SETTINGS IN THE URL (see config/db.properties)
 *    cachePrepStmts=true          -> reuse prepared statements instead of re-parsing SQL
 *    useServerPrepStmts=true      -> let the MySQL server pre-compile our SQL
 *    rewriteBatchedStatements=true-> send batches as one network round trip
 * ============================================================================
 */
public class MySqlConnectionProvider implements ConnectionProvider {

    private final String url;
    private final String user;
    private final String password;

    public MySqlConnectionProvider(String url, String user, String password) {
        this.url = url;
        this.user = user;
        this.password = password;
    }

    @Override
    public String getName() {
        return "MySQL";
    }

    @Override
    public Connection openConnection() throws SQLException {
        return DriverManager.getConnection(url, user, password);
    }

    @Override
    public List<String> getSchemaStatements() {
        return List.of(
            """
            CREATE TABLE IF NOT EXISTS users (
                id            BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
                mobile_number VARCHAR(11)   NOT NULL UNIQUE,
                pin           VARCHAR(64)   NOT NULL,
                pin_salt      VARCHAR(32)   NOT NULL,
                full_name     VARCHAR(100)  NOT NULL,
                balance       DECIMAL(15,2) NOT NULL DEFAULT 0.00
            ) ENGINE=InnoDB""",
            // ENGINE=InnoDB: the MySQL storage engine that supports
            // transactions (COMMIT/ROLLBACK) and foreign keys. We NEED both.
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id          BIGINT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
                user_id     BIGINT        NOT NULL,
                type        VARCHAR(20)   NOT NULL,
                amount      DECIMAL(15,2) NOT NULL,
                details     VARCHAR(255),
                created_at  DATETIME      NOT NULL,
                INDEX idx_transactions_user (user_id, created_at),
                CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES users(id)
            ) ENGINE=InnoDB"""
        );
    }
}

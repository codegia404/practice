package com.jcash.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

/*
 * ============================================================================
 *  DatabaseManager: owns the ONE database connection of the app
 * ============================================================================
 *  WHY ONLY ONE CONNECTION?
 *    Opening a database connection is SLOW: for MySQL it means a network
 *    handshake, a login, and memory on the server. A console app serves one
 *    person at a time, so we open ONE connection at start-up, REUSE it for
 *    every query, and close it on exit. (Data-access tuning, Step I.)
 *    A web app with many simultaneous users would use a CONNECTION POOL
 *    (such as HikariCP) instead, which is many reusable connections.
 *
 *  WHY DOES IT HOLD A ConnectionProvider AND NOT A URL?
 *    Because DatabaseManager shouldn't care WHICH database it is. It just
 *    asks the provider "give me a connection" and "give me your schema".
 *    That's DEPENDENCY INJECTION: the needed object is "injected" through
 *    the constructor instead of being created inside the class.
 *
 *  "implements AutoCloseable" lets us use it in try-with-resources, so the
 *  connection is ALWAYS closed, even if the program crashes with an error.
 * ============================================================================
 */
public class DatabaseManager implements AutoCloseable {

    private final ConnectionProvider provider;
    private Connection connection;

    public DatabaseManager(ConnectionProvider provider) {
        this.provider = provider;
    }

    public String getDatabaseName() {
        return provider.getName();
    }

    /*
     * LAZY INITIALIZATION: the connection is created the first time someone
     * asks for it, not before. If it was closed or dropped (e.g. MySQL
     * restarted), we open a fresh one automatically.
     */
    public Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            connection = provider.openConnection();
        }
        return connection;
    }

    /* Creates the tables if they don't exist yet. Safe to call every start-up. */
    public void initializeSchema() throws SQLException {
        try (Statement st = getConnection().createStatement()) {
            for (String sql : provider.getSchemaStatements()) {
                st.execute(sql);
            }
        }
    }

    // ---------------------------------------------------------------------------
    // JDBC TRANSACTION HELPERS
    // A DATABASE TRANSACTION groups several SQL statements into ONE all-or-
    // nothing unit. Example: a money transfer = subtract from sender + add to
    // receiver + write 2 logs. If the app crashes after the subtraction but
    // before the addition, money would VANISH. With a transaction we either
    // COMMIT (save everything) or ROLLBACK (undo everything). This is the
    // "A" (Atomicity) in ACID.
    // ---------------------------------------------------------------------------

    /** Start a transaction: from now on nothing is saved until commit(). */
    public void beginTransaction() throws SQLException {
        getConnection().setAutoCommit(false);
    }

    /** Save every change made since beginTransaction(). */
    public void commit() throws SQLException {
        Connection c = getConnection();
        c.commit();
        c.setAutoCommit(true);   // back to normal "save each statement" mode
    }

    /** Undo every change made since beginTransaction(). Never throws. */
    public void rollbackQuietly() {
        try {
            Connection c = getConnection();
            c.rollback();
            c.setAutoCommit(true);
        } catch (SQLException e) {
            // We are already handling another error; don't hide it with this one.
            System.err.println("Warning: rollback failed: " + e.getMessage());
        }
    }

    @Override
    public void close() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Warning: could not close database connection: " + e.getMessage());
        }
    }
}

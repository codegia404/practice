package com.jcash.util;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.HexFormat;

/*
 * ============================================================================
 *  PinHasher: turns a PIN into a hash so we never store the real PIN
 * ============================================================================
 *  WHAT IS HASHING?
 *    A hash function turns any input into a fixed-length "fingerprint":
 *        SHA-256("1234" + salt)  ->  "9f86d081884c7d65..."  (64 hex characters)
 *    It is ONE-WAY: you can't turn the fingerprint back into "1234". To
 *    check a login, we hash what the user typed and compare fingerprints.
 *
 *  WHAT IS A SALT AND WHY DO WE NEED IT?
 *    Without a salt, everyone with PIN "1234" would have the SAME hash, and
 *    an attacker could pre-compute the hashes of all 10,000 PINs. A salt
 *    is a random value, DIFFERENT for each user, mixed in before hashing.
 *    Now identical PINs give different hashes.
 *
 *  HONEST NOTE FOR LEARNERS
 *    A 4-digit PIN has only 10,000 possibilities, so hashing alone can't
 *    make it strong. Real banks also LIMIT LOGIN ATTEMPTS (our 3 tries) and
 *    use slow hashing algorithms such as BCrypt or PBKDF2. SHA-256 + salt
 *    is used here because it's built into Java and easy to understand.
 *
 *  WHY ARE ALL METHODS "static"?
 *    PinHasher has no data of its own (no fields to remember). It's just a
 *    toolbox of functions, like Math.max(). So we call PinHasher.hash(...)
 *    directly without creating an object. That's the typical shape of a
 *    "util" class, and the private constructor stops anyone creating one.
 * ============================================================================
 */
public final class PinHasher {

    // SecureRandom is a cryptographically strong random generator. The
    // normal java.util.Random is predictable, so it must never be used for
    // security. We create it ONCE because creating it is expensive.
    private static final SecureRandom RANDOM = new SecureRandom();

    private PinHasher() {
        // utility class: no objects allowed
    }

    /** Creates a new random 16-byte salt, written as 32 hex characters. */
    public static String generateSalt() {
        byte[] salt = new byte[16];
        RANDOM.nextBytes(salt);
        return HexFormat.of().formatHex(salt);
    }

    /** Returns SHA-256(salt + pin) as 64 hex characters. */
    public static String hash(String pin, String salt) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashed = digest.digest((salt + pin).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(hashed);
        } catch (NoSuchAlgorithmException e) {
            // Every Java installation MUST support SHA-256, so this can't
            // really happen. We wrap it in an unchecked exception.
            throw new IllegalStateException("SHA-256 not available", e);
        }
    }

    /*
     * Checks a typed PIN against the stored hash.
     * MessageDigest.isEqual() compares in "constant time": it always takes
     * the same time whether the first or the last character differs. A
     * normal String.equals() stops at the first difference, and attackers
     * can measure that tiny time difference ("timing attack").
     */
    public static boolean matches(String typedPin, String salt, String storedHash) {
        String typedHash = hash(typedPin, salt);
        return MessageDigest.isEqual(
                typedHash.getBytes(StandardCharsets.UTF_8),
                storedHash.getBytes(StandardCharsets.UTF_8));
    }
}

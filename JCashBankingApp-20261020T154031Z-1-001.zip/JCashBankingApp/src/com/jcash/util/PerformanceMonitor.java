package com.jcash.util;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryMXBean;
import java.lang.management.MemoryUsage;
import java.lang.management.OperatingSystemMXBean;
import java.lang.management.RuntimeMXBean;
import java.lang.management.ThreadMXBean;
import java.time.Duration;

/*
 * ============================================================================
 *  PerformanceMonitor  (Step I: monitor OS performance + language-level tuning)
 * ============================================================================
 *  WHAT ARE "MXBeans"?
 *    The JVM has built-in "sensors" called Management Beans (MXBeans). They
 *    report live numbers about the running program and the operating system:
 *      MemoryMXBean           -> heap memory used / max
 *      OperatingSystemMXBean  -> CPU load, number of processors, RAM
 *      ThreadMXBean           -> how many threads are running
 *      GarbageCollectorMXBean -> how often garbage collection ran, and how long it took
 *      RuntimeMXBean          -> uptime and the JVM flags we started with
 *    Tools like JConsole and VisualVM read these SAME beans. We read them in
 *    code so the app can show a mini performance dashboard (menu option 5).
 *
 *  THE SECOND HALF: LANGUAGE-LEVEL BENCHMARKS
 *    runLanguageLevelBenchmarks() PROVES two classic tuning rules with real
 *    timings:
 *      1. Use StringBuilder, not "+" inside loops, to build strings.
 *      2. Use primitives (long), not wrappers (Long), in heavy math loops.
 * ============================================================================
 */
public final class PerformanceMonitor {

    private static final long MB = 1024L * 1024L;

    private PerformanceMonitor() {
    }

    /** Builds a text report of the JVM and OS performance numbers. */
    public static String buildReport() {
        MemoryMXBean memory = ManagementFactory.getMemoryMXBean();
        OperatingSystemMXBean os = ManagementFactory.getOperatingSystemMXBean();
        ThreadMXBean threads = ManagementFactory.getThreadMXBean();
        RuntimeMXBean runtime = ManagementFactory.getRuntimeMXBean();
        MemoryUsage heap = memory.getHeapMemoryUsage();

        // StringBuilder: we append many pieces, so we use ONE growable buffer
        // instead of creating a new String object for every "+".
        StringBuilder sb = new StringBuilder(1024);
        sb.append("\n========== SYSTEM PERFORMANCE MONITOR ==========\n");
        sb.append("Operating system : ").append(os.getName()).append(' ')
          .append(os.getVersion()).append(" (").append(os.getArch()).append(")\n");
        sb.append("CPU cores        : ").append(os.getAvailableProcessors()).append('\n');
        sb.append("System load avg  : ").append(formatLoad(os.getSystemLoadAverage())).append('\n');

        // The com.sun.management version of the bean has extra numbers (CPU %,
        // physical RAM). It exists in every normal JDK (HotSpot/OpenJDK), but we
        // check with "instanceof" to be safe. Java 16+ "pattern matching"
        // declares the variable "sunOs" in the same line.
        if (os instanceof com.sun.management.OperatingSystemMXBean sunOs) {
            sb.append("System CPU usage : ").append(percent(sunOs.getCpuLoad())).append('\n');
            sb.append("JVM CPU usage    : ").append(percent(sunOs.getProcessCpuLoad())).append('\n');
            sb.append("Physical RAM     : ").append(sunOs.getFreeMemorySize() / MB).append(" MB free of ")
              .append(sunOs.getTotalMemorySize() / MB).append(" MB\n");
        }

        sb.append("\n-- JVM memory --\n");
        sb.append("Heap used        : ").append(heap.getUsed() / MB).append(" MB\n");
        sb.append("Heap committed   : ").append(heap.getCommitted() / MB).append(" MB\n");
        sb.append("Heap max (-Xmx)  : ").append(heap.getMax() / MB).append(" MB\n");
        sb.append("Live threads     : ").append(threads.getThreadCount()).append('\n');
        sb.append("JVM uptime       : ").append(formatDuration(runtime.getUptime())).append('\n');

        sb.append("\n-- Garbage collectors --\n");
        for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
            sb.append(String.format("%-25s runs=%d, total time=%d ms%n",
                    gc.getName(), gc.getCollectionCount(), gc.getCollectionTime()));
        }

        sb.append("\n-- JVM flags this app was started with --\n");
        if (runtime.getInputArguments().isEmpty()) {
            sb.append("(none: start with scripts/run.sh to apply the tuned JVM flags)\n");
        } else {
            for (String arg : runtime.getInputArguments()) {
                sb.append("  ").append(arg).append('\n');
            }
        }
        sb.append("================================================\n");
        return sb.toString();
    }

    /*
     * Runs two mini experiments and returns the timings as text.
     * System.nanoTime() is the right clock for measuring elapsed time
     * (System.currentTimeMillis() can jump if the computer's clock changes).
     */
    public static String runLanguageLevelBenchmarks() {
        final int stringLoops = 20_000;   // underscores just make big numbers readable
        final int mathLoops = 5_000_000;

        StringBuilder report = new StringBuilder(512);
        report.append("\n====== LANGUAGE-LEVEL PERFORMANCE DEMO ======\n");

        // ---- Experiment 1: String "+" vs StringBuilder ----
        // Strings are IMMUTABLE. "text = text + x" creates a NEW String and
        // copies ALL old characters every time, so the work grows like n^2.
        long start = System.nanoTime();
        String text = "";
        for (int i = 0; i < stringLoops; i++) {
            text = text + 'x';
        }
        long concatMs = (System.nanoTime() - start) / 1_000_000;

        // StringBuilder keeps ONE growable array and just adds to the end.
        start = System.nanoTime();
        StringBuilder builder = new StringBuilder(stringLoops);  // pre-sized: no re-growing
        for (int i = 0; i < stringLoops; i++) {
            builder.append('x');
        }
        String built = builder.toString();
        long builderMs = (System.nanoTime() - start) / 1_000_000;

        report.append(String.format("String '+' x %,d       : %5d ms (length %d)%n", stringLoops, concatMs, text.length()));
        report.append(String.format("StringBuilder x %,d   : %5d ms (length %d)%n", stringLoops, builderMs, built.length()));

        // ---- Experiment 2: wrapper Long vs primitive long ----
        // "Long sum" is an OBJECT. Every "sum += i" unboxes it, adds, then
        // creates a NEW Long object (autoboxing). Millions of throw-away
        // objects means more work for the garbage collector.
        start = System.nanoTime();
        Long boxedSum = 0L;
        for (int i = 0; i < mathLoops; i++) {
            boxedSum += i;
        }
        long boxedMs = (System.nanoTime() - start) / 1_000_000;

        start = System.nanoTime();
        long primitiveSum = 0L;   // a plain number in a CPU register: no objects at all
        for (int i = 0; i < mathLoops; i++) {
            primitiveSum += i;
        }
        long primitiveMs = (System.nanoTime() - start) / 1_000_000;

        report.append(String.format("Boxed Long sum x %,d  : %5d ms (sum %d)%n", mathLoops, boxedMs, boxedSum));
        report.append(String.format("Primitive long x %,d  : %5d ms (sum %d)%n", mathLoops, primitiveMs, primitiveSum));
        report.append("Lesson: StringBuilder + primitives in hot loops = less garbage, faster code.\n");
        report.append("(Timings vary by machine; the JIT compiler may speed up repeated runs.)\n");
        report.append("=============================================\n");
        return report.toString();
    }

    // ---- small private helpers -------------------------------------------------

    private static String percent(double fraction) {
        // The beans return a negative number when the value is not available yet.
        return fraction < 0 ? "n/a" : String.format("%.1f%%", fraction * 100);
    }

    private static String formatLoad(double load) {
        return load < 0 ? "n/a (not supported on Windows)" : String.format("%.2f", load);
    }

    private static String formatDuration(long millis) {
        Duration d = Duration.ofMillis(millis);
        return String.format("%dm %ds", d.toMinutes(), d.toSecondsPart());
    }
}

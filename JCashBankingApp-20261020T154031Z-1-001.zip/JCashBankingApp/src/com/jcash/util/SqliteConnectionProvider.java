package com.jcash.util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

/*
 * ============================================================================
 *  SqliteConnectionProvider: the SQLite implementation of ConnectionProvider
 * ============================================================================
 *  WHAT IS SQLITE?
 *    A complete SQL database stored in ONE ordinary file (data/jcash.db).
 *    There's no server to install or start. The "server" is the driver
 *    jar inside lib/. That makes it perfect for demos and assessments.
 *
 *  SQLITE QUIRKS WE HANDLE HERE
 *    1. SQLite has no exact DECIMAL type. If we declared "balance DECIMAL",
 *       SQLite would quietly store it as a floating-point REAL, which has the
 *       same rounding problem as Java's double! So we store money as TEXT
 *       (e.g. "5000.00") and convert it to BigDecimal in Java. That's exact.
 *    2. Foreign keys are OFF by default in SQLite. We switch them ON every
 *       time we connect with "PRAGMA foreign_keys = ON".
 * ============================================================================
 */
public class SqliteConnectionProvider implements ConnectionProvider {

    private final String url;   // e.g. "jdbc:sqlite:data/jcash.db"

    public SqliteConnectionProvider(String url) {
        this.url = url;
    }

    @Override
    public String getName() {
        return "SQLite";
    }

    @Override
    public Connection openConnection() throws SQLException {
        createParentFolder();
        // DriverManager finds the right driver automatically from the URL
        // prefix "jdbc:sqlite:", as long as the driver jar is on the classpath.
        Connection connection = DriverManager.getConnection(url);
        // try-with-resources: the Statement is closed automatically at the "}"
        try (Statement st = connection.createStatement()) {
            st.execute("PRAGMA foreign_keys = ON");
            // WAL (Write-Ahead Logging) mode makes writes faster and lets
            // reads continue while a write happens. (Performance tuning, Step I.)
            st.execute("PRAGMA journal_mode = WAL");
        }
        return connection;
    }

    /* SQLite creates the .db FILE for us, but not missing FOLDERS. */
    private void createParentFolder() throws SQLException {
        String filePath = url.substring("jdbc:sqlite:".length());
        Path parent = Path.of(filePath).toAbsolutePath().getParent();
        try {
            if (parent != null) {
                Files.createDirectories(parent);
            }
        } catch (IOException e) {
            throw new SQLException("Cannot create folder for SQLite file: " + parent, e);
        }
    }

    @Override
    public List<String> getSchemaStatements() {
        // List.of(...) creates a small, unmodifiable list in one line.
        return List.of(
            """
            CREATE TABLE IF NOT EXISTS users (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                mobile_number TEXT    NOT NULL UNIQUE,
                pin           TEXT    NOT NULL,
                pin_salt      TEXT    NOT NULL,
                full_name     TEXT    NOT NULL,
                balance       TEXT    NOT NULL DEFAULT '0.00'
            )""",
            """
            CREATE TABLE IF NOT EXISTS transactions (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id     INTEGER NOT NULL REFERENCES users(id),
                type        TEXT    NOT NULL,
                amount      TEXT    NOT NULL,
                details     TEXT,
                created_at  TEXT    NOT NULL
            )""",
            // An INDEX is like the index at the back of a book: the database can
            // jump straight to one user's transactions instead of reading every
            // row. Without it, "show my logs" gets slower as the table grows.
            "CREATE INDEX IF NOT EXISTS idx_transactions_user ON transactions(user_id, created_at)"
        );
    }
}

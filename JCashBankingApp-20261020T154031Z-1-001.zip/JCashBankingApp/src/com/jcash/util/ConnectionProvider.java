package com.jcash.util;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

/*
 * ============================================================================
 *  ConnectionProvider: an INTERFACE (a contract)
 * ============================================================================
 *  THE PROBLEM WE ARE SOLVING
 *    We want the app to work with TWO databases: SQLite and MySQL. They
 *    mostly speak the same SQL, but they differ in a few places:
 *       - the JDBC URL and login details
 *       - auto-increment syntax:  SQLite "AUTOINCREMENT" vs MySQL "AUTO_INCREMENT"
 *       - data types (MySQL has a real DECIMAL type, SQLite doesn't)
 *
 *  THE SOLUTION: PROGRAM TO AN INTERFACE
 *    An interface lists WHAT something can do without saying HOW. Any class
 *    that "implements ConnectionProvider" MUST provide these methods. The
 *    rest of the app only ever sees the type "ConnectionProvider". It
 *    doesn't know or care whether SQLite or MySQL is behind it.
 *
 *          ConnectionProvider  (interface)
 *             ├── SqliteConnectionProvider
 *             └── MySqlConnectionProvider
 *
 *    This is POLYMORPHISM + ABSTRACTION. Adding PostgreSQL later would mean
 *    writing ONE new class. Not a single line in the services would change.
 *    That's the "O" in the SOLID principles: Open for extension, Closed
 *    for modification.
 * ============================================================================
 */
public interface ConnectionProvider {

    /** A short name for messages, e.g. "SQLite" or "MySQL". */
    String getName();

    /** Opens a brand-new JDBC connection to the database. */
    Connection openConnection() throws SQLException;

    /**
     * The CREATE TABLE / CREATE INDEX statements written in THIS database's
     * SQL dialect. They are run at start-up, and "IF NOT EXISTS" makes them
     * safe to run every time.
     */
    List<String> getSchemaStatements();
}

package com.jcash.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/*
 * ============================================================================
 *  DatabaseConfig: reads config/db.properties and picks the right database
 * ============================================================================
 *  WHY A CONFIG FILE INSTEAD OF HARD-CODING THE URL?
 *    Passwords and server addresses change between computers (your laptop,
 *    the Codespace, the assessor's PC). If they're hard-coded you must
 *    edit and recompile Java code to change them. With a .properties file
 *    you edit ONE text line and run again. Code = logic; config = settings.
 *
 *  THE FACTORY METHOD: createProvider()
 *    It reads "db.type" and returns EITHER a SqliteConnectionProvider OR a
 *    MySqlConnectionProvider, but the return type is the INTERFACE
 *    ConnectionProvider. The caller never knows which one it got. This is
 *    the "Factory" design pattern and it is where polymorphism is chosen.
 *
 *  OVERRIDING FROM THE COMMAND LINE
 *    You can switch databases without editing the file:
 *        java -Djcash.db.type=mysql ...      (scripts/run.sh mysql does this)
 *    System properties (-D...) win over the file.
 * ============================================================================
 */
public class DatabaseConfig {

    public static final String DEFAULT_CONFIG_PATH = "config/db.properties";

    private final Properties properties = new Properties();

    public DatabaseConfig(String configPath) throws IOException {
        Path path = Path.of(configPath);
        if (!Files.exists(path)) {
            throw new IOException("Config file not found: " + path.toAbsolutePath()
                    + "\nRun the app from the project root folder (the folder that contains 'config').");
        }
        // try-with-resources closes the file even if an error happens.
        try (InputStream in = Files.newInputStream(path)) {
            properties.load(in);
        }
    }

    /* Reads a setting: -Dname=value on the command line first, else the file. */
    private String get(String key, String defaultValue) {
        String fromCommandLine = System.getProperty("jcash." + key);
        if (fromCommandLine != null && !fromCommandLine.isBlank()) {
            return fromCommandLine.trim();
        }
        return properties.getProperty(key, defaultValue).trim();
    }

    public String getDatabaseType() {
        return get("db.type", "sqlite").toLowerCase();
    }

    /** FACTORY METHOD: returns the correct implementation behind the interface. */
    public ConnectionProvider createProvider() {
        String type = getDatabaseType();
        // "switch" on a String with the modern arrow syntax (Java 14+).
        return switch (type) {
            case "sqlite" -> new SqliteConnectionProvider(
                    get("sqlite.url", "jdbc:sqlite:data/jcash.db"));
            case "mysql" -> new MySqlConnectionProvider(
                    get("mysql.url", "jdbc:mysql://localhost:3306/jcash_db"),
                    get("mysql.user", "root"),
                    get("mysql.password", ""));
            default -> throw new IllegalArgumentException(
                    "Unknown db.type '" + type + "'. Use 'sqlite' or 'mysql'.");
        };
    }
}

# JCash Banking App

TESDA Programming (Java) NC III, Set X. This is a console banking app built with OOP and JDBC, and it runs on SQLite or MySQL.
The full step-by-step teaching guide is **JCash_Guide.pdf**.

## Quick start (GitHub Codespaces)
```bash
chmod +x scripts/*.sh
./scripts/build.sh          # compile
./scripts/run.sh            # run with SQLite (default)

./scripts/start-mysql.sh    # optional: start MySQL in Docker
./scripts/run.sh mysql      # run with MySQL
```

## Demo accounts (created automatically on first run)
| Name           | Mobile      | PIN  | Opening balance |
|----------------|-------------|------|-----------------|
| Juan Dela Cruz | 09171234567 | 1234 | 5,000.00        |
| Maria Santos   | 09182345678 | 5678 | 3,000.00        |
| Pedro Reyes    | 09193456789 | 0000 | 0.00            |

To start over with fresh data, delete the `data/` folder (SQLite) or run
`DROP DATABASE jcash_db;` (MySQL).

## Structure
```
src/com/jcash/
  JCashApp.java   main class + console menus
  model/          BaseEntity, User, Transaction, TransactionType
  repository/     interfaces + JDBC implementations (all SQL lives here)
  service/        AuthService, AccountService, TransactionService, DataSeeder
  exception/      custom business exceptions
  util/           DB config/connections, PinHasher, MoneyFormatter, InputHelper, PerformanceMonitor
config/db.properties   choose sqlite or mysql
lib/                   JDBC driver jars
```

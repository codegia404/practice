#!/usr/bin/env bash
# ---------------------------------------------------------------------
# start-mysql.sh: starts a MySQL 8.4 server inside Docker (works in GitHub
# Codespaces). Run it once per Codespace session, then: ./scripts/run.sh mysql
#   --memory=512m                  : CONTAINER-LEVEL TUNING (Step I). Caps MySQL's
#                                    RAM so it can't starve the Java app.
#   --innodb-buffer-pool-size=256M : MySQL's main cache for table data/indexes
#   --max-connections=50           : we only need a few connections; fewer = less RAM
# ---------------------------------------------------------------------
set -e
NAME=jcash-mysql
if ! docker info >/dev/null 2>&1; then
  echo "Docker is not running. In a Codespace, rebuild the container so the"
  echo "docker-in-docker feature is active. On your PC, start Docker Desktop first."
  exit 1
fi
if docker ps -a --format '{{.Names}}' | grep -q "^${NAME}$"; then
  echo "Starting existing container $NAME ..."
  docker start "$NAME" >/dev/null
else
  echo "Creating MySQL container $NAME (first time: downloads the image) ..."
  docker run -d --name "$NAME" \
    -e MYSQL_ROOT_PASSWORD=jcash123 \
    -e MYSQL_DATABASE=jcash_db \
    -p 3306:3306 \
    --memory=512m \
    mysql:8.4 \
    --innodb-buffer-pool-size=256M --max-connections=50 >/dev/null
fi
printf "Waiting for MySQL to be ready"
until docker exec "$NAME" mysql -h 127.0.0.1 -uroot -pjcash123 -e "SELECT 1" >/dev/null 2>&1; do
  printf "."
  sleep 2
done
echo " ready!"
echo "Open a MySQL prompt with: docker exec -it $NAME mysql -uroot -pjcash123 jcash_db"

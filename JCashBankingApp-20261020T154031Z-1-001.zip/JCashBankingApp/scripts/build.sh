#!/usr/bin/env bash
# ---------------------------------------------------------------------
# build.sh: compiles every .java file in src/ into the out/ folder.
#   -d out          : put the compiled .class files in out/
#   -cp "lib/*"     : the classpath; "lib/*" means "every jar in lib/"
#   -encoding UTF-8 : read the source files as UTF-8 on every OS
#   @sources.txt    : javac reads the list of files to compile from this file
# ---------------------------------------------------------------------
set -e                                  # stop at the first error
cd "$(dirname "$0")/.."                 # always run from the project root
rm -rf out && mkdir -p out
find src -name "*.java" > out/sources.txt
javac -encoding UTF-8 -Xlint:unchecked -d out -cp "lib/*" @out/sources.txt
echo "Build successful -> out/"

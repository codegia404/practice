#!/usr/bin/env bash
# ---------------------------------------------------------------------
# run.sh: runs the app with TUNED JVM settings (Step I, JVM runtime layer)
#   Usage:  ./scripts/run.sh            (database from config/db.properties)
#           ./scripts/run.sh mysql      (force MySQL)
#           ./scripts/run.sh sqlite     (force SQLite)
#
#   -Xms64m  : starting heap size. Starting near what the app needs avoids
#              repeated heap resizing during start-up.
#   -Xmx256m : MAXIMUM heap size. A cap keeps the app from eating all the
#              container's memory. If it's exceeded we get OutOfMemoryError
#              (and a heap dump, thanks to the flags below) instead of
#              the whole Codespace slowing down.
#   -XX:+UseG1GC                    : G1 garbage collector, balanced for short pauses
#   -XX:MaxGCPauseMillis=100        : ask G1 to keep pauses under 100 ms
#   -XX:+UseStringDeduplication     : G1 merges identical String contents to save memory
#   -XX:+HeapDumpOnOutOfMemoryError : save memory contents if we run out, for analysis
#   -Xlog:gc*:file=logs/gc.log      : write garbage-collection activity to a log file
#   You can replace all of these:   JAVA_OPTS="-Xmx512m" ./scripts/run.sh
# ---------------------------------------------------------------------
set -e
cd "$(dirname "$0")/.."
[ -d out/com ] || ./scripts/build.sh    # build first if needed
mkdir -p logs

DEFAULT_OPTS="-Xms64m -Xmx256m -XX:+UseG1GC -XX:MaxGCPauseMillis=100 -XX:+UseStringDeduplication"
DEFAULT_OPTS="$DEFAULT_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=logs"
DEFAULT_OPTS="$DEFAULT_OPTS -Xlog:gc*:file=logs/gc.log:time,uptime,level,tags"
JAVA_OPTS="${JAVA_OPTS:-$DEFAULT_OPTS}"

DB_OVERRIDE=""
if [ -n "$1" ]; then
  DB_OVERRIDE="-Djcash.db.type=$1"
fi

# On Linux/macOS the classpath separator is ":" (on Windows it is ";").
exec java $JAVA_OPTS $DB_OVERRIDE -cp "out:lib/*" com.jcash.JCashApp
